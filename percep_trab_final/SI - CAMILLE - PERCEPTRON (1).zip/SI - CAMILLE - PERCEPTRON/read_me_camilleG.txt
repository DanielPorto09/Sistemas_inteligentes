Camille Grajauskas Gonçalves 22101864

Versão Python: 3.10.14
Bibliotecas: Numpy; matplotlib e scikit-learn

O código foi feito no ambiente virtual Replit pela familiaridade maior.

No inicio do codigo é possivel visualizar todos os parametros alteraveis para visualizar o desempenho do perceptron..
Os mais usados sao numero de amostra, classes e distancia, ja que suas mudancas sao mais visiveis...
Os demais parametros alteram tanto na validação dos dados como no treinamento

Para visualizar os resultados temos algumas formas...
Será printado a acuracia e a precisao media, assim como as matrizes de confusao criadas para esses calculos...

Os dois graficos possiveis de se ver e utilizados tambem no relatorio são:
- dados no plano xy com os atributos, suas localizações e linhas de decisão
- erro x iteração para acompanhar a estabilização ao longo do tempo

Está bem explicito no codigo aonde é preciso comentar ou descomentar para ver um ou outro.