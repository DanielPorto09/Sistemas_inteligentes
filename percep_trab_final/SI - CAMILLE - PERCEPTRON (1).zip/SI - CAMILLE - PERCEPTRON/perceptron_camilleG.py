## Camille Grajauskas Gonçalves 22101864 ##
## Sistemas Inteligentes - Pablo Andretta ##

#bibliotecas ------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, precision_score, confusion_matrix
from sklearn.base import BaseEstimator, ClassifierMixin

#dados iniciais -----------------------------------------------

n_amostras = 100         
atributos = 2           #sempre 2... x e y no grafico 
n_classes = 5          #min duas 
separacao = 1.5           #separação entre as classes... distancia 
seed = 8                #usado para repetir os testes 
n_divisoes = 2                #para a validacao cruzada
estado_aleatorio = 1          #reprodução dos resultados
embaralhar = True             #antes da divisão
n_iteracoes = 20        #para o treinamento do perceptron 
tx_aprendizado = 0.01   #do perceptron 

#funções ----------------------------------------------------

def plotar_graf(X, y, rede):
  cores = ('lightgreen' , 'red', 'orange', 'green', 'yellow', 'pink', 'cyan', 'magenta')
  cmap = ListedColormap(cores[:len(np.unique(y))])
  markers = ('^', 'v', 's', 'x', 'o') #icone dos dados
  resolucao = 0.03
  x1_min, x1_max = X[:, 0].min() - 1, X[:, 1].max() + 1 #limites do graf baseado em x
  x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
  x1, x2 = np.meshgrid(np.arange(x1_min, x1_max, resolucao), np.arange(x2_min, x2_max, resolucao)) #gera malha
  classificacao = rede.previsao(np.array([x1.ravel(), x2.ravel()]).T) #prever classes para pontos no graf
    # ^ ravel achata... matriz transposta
  classificacao = classificacao.reshape(x1.shape)
  plt.contourf(x1, x2, classificacao, alpha = 0.1, cmap = cmap) #regiões de decisão
  for idx, cl in enumerate(np.unique(y)): #plotando os pontos de dados...
    plt.scatter(x=X[y==cl, 0], y=X[y==cl, 1], alpha=0.4, color=cmap(idx), marker=markers[idx], label=cl)
      
  plt.xlabel('atributo 1')
  plt.ylabel('atributo 2')
  plt.title('Regiões de Decisão')


def base_dados(n_amostras, atributos, n_classes, separacao, seed): 
    if seed is not None: 
        np.random.seed(seed)  #reproduzir os dados caso necessario 
    X = np.zeros((n_amostras * n_classes, atributos))  #inicializa x e y
    y = np.zeros(n_amostras * n_classes, dtype = int)
    for i in range(n_classes):  #roda ate n de classes
        center = separacao * (i - (n_classes - 1) / 2)  #centro de acordo com a separação
        X[i*n_amostras:(i+1)*n_amostras] = np.random.normal(loc=center, scale=0.2, size=(n_amostras, atributos))  
        y[i*n_amostras:(i+1)*n_amostras] = i   
    return X, y


def plotar_taxa_erros(rede): #para o grafico de erros x iteração 
  plt.plot(range(1, len(rede.erro_) + 1), rede.erro_, marker='o')
  plt.xlabel('iterações')
  plt.ylabel('erros')
  plt.title('Convergência do Perceptron')
    
def rotulos(n):  #rotulos binarios aos dados... de acordo com a classe que pertencem 
  for i in range(n_classes):
    if(i==n):
      for j in range(i*n_amostras):
        y[j] = -1
          
  for i in range(n_classes*n_amostras):
    if (y[i] != -1):
      y[i] = 1
        
  return y

#classes perceptron-----------------------------------------------------

class Perceptron:
    def __init__(self, taxa_aprendizado, n_iter):
        self.taxa_aprendizado = taxa_aprendizado
        self.n_iter = n_iter

    def previsao(self, X): #saida do perceptron com base no neuronio
                    #  ^ X é a entrada do perceptron
        return np.where(self.saida_neuronio(X) >= 0.0, 1, -1) #acima de zero é 1, else é -1
      
    def saida_neuronio(self, X): 
        return np.dot(X, self.pesos_[1:]) + self.pesos_[0]
                 # ^ produto escalar entre a entrada e o peso do neuronio + combinação linear
  
    def ajustar_pesos(self, X, y):
        self.pesos_ = np.zeros(X.shape[1] + 1)  #erros em cada iteração
        self.erro_ = []
        for _ in range(self.n_iter): 
            erro = 0 #evitar unbound
            for xi, y_real in zip(X, y): #para cada amostra com sua classe
                erro_calc = y_real - self.previsao(xi)
                peso_ajustado = self.taxa_aprendizado * erro_calc
                self.pesos_[1:] += peso_ajustado * xi #ajustando de acordo com erro calculado...
                self.pesos_[0] += peso_ajustado
                erro += int(peso_ajustado != 0.0) #atualizando...
            self.erro_.append(erro)


class PerceptronAdapter(BaseEstimator, ClassifierMixin): #compativel com sklearn... servira para validação
    def __init__(self, taxa_aprendizado, n_iter):
        self.taxa_aprendizado = taxa_aprendizado
        self.n_iter = n_iter
        self.perceptron = Perceptron(taxa_aprendizado, n_iter) #instancia do perceptron

    def fit(self, X, y): #treina com os dados
        self.perceptron.ajustar_pesos(X, y)  
        self.classes_ = np.unique(y)  #armazenando...
        return self

    def predict(self, X):
        return self.perceptron.previsao(X)  #fazendo previsoes com o perceptron treinado

#validação, testes e graficos... -----------------------------------------------------------

rede_perceptron = Perceptron(taxa_aprendizado=tx_aprendizado, n_iter=n_iteracoes)

X, y = base_dados(n_amostras, atributos, n_classes, separacao, seed)

#plotar graficos AQUI <<<<<<<<<<<<<<<<<<
for i in range(n_classes-1): 
    y = rotulos(i+1)
    rede_perceptron.ajustar_pesos(X,y)
    plotar_graf(X, y, rede_perceptron) #descomente para ter o graf de dados
#plotar_taxa_erros(rede_perceptron) #descomente para ter o graf erros x iteracao

#gerando a base de dados...
X, y = base_dados(n_amostras, atributos, n_classes, separacao, seed)

perceptron_adapter = PerceptronAdapter(taxa_aprendizado=tx_aprendizado, n_iter=n_iteracoes) #puxando valores

kf = KFold(n_splits=n_divisoes, shuffle=embaralhar, random_state=estado_aleatorio)
# ^ validacao cruzada

accuracies = []  #acuracias e precisões de cada reta de decisão
precisions = []  
confusion_matrices = []  #por extenso... matriz de confusao


for i in range(n_classes-1): #calculos e matriz de confusão para cada reta de decisão
  y = rotulos(i+1)
  for train_index, test_index in kf.split(X):
      X_train, X_test = X[train_index], X[test_index] #dados de treinamento e dados de teste para infos
      y_train, y_test = y[train_index], y[test_index]

      perceptron_adapter.fit(X_train, y_train)
      y_pred = perceptron_adapter.predict(X_test)

      accuracy = accuracy_score(y_test, y_pred) #acuracia e precisao calculadas pelo sklearn
      precision = precision_score(y_test, y_pred)
      accuracies.append(accuracy)
      precisions.append(precision)

      cm = confusion_matrix(y_test, y_pred) #confusion matrix calculada tb com funcao importada
      confusion_matrices.append(cm)

#printando infos... --------------------------------------------------------
    
mean_accuracy = sum(accuracies) / len(accuracies)
print("acurácia média:", np.mean(accuracies)) 

mean_precision = sum(precisions) / len(precisions)
print("precisão média:", np.mean(precisions))
for i, cm in enumerate(confusion_matrices): #printando cms para cada reta
    print(f"matriz de confusão para a reta {i + 1}:")
    print(cm)
    
plt.show() #para rodar o plot por final e nao atrapalhar o print